
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was ShEarthSDKConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)
find_dependency(OpenSceneGraph 3.6 COMPONENTS osg osgDB osgGA osgText osgUtil osgViewer)
find_dependency(osgEarth 3.8 CONFIG)

if(ON)
    find_dependency(Qt6 6.11 COMPONENTS Core Gui Widgets OpenGL OpenGLWidgets)
    find_dependency(OpenGL)
    find_dependency(GDAL)
    find_dependency(CURL)
endif()

if(ON)
    find_dependency(CURL)
    find_dependency(PNG)
    find_dependency(JPEG)
    find_dependency(ZLIB)
endif()

if(ON)
    # Only the stable runtime API is public. Legacy Fe libraries and map
    # plugins are installed as runtime dependencies, not SDK link targets.
    if(NOT TARGET FreeEarth::Runtime)
        add_library(FreeEarth::Runtime SHARED IMPORTED)
        set_target_properties(FreeEarth::Runtime PROPERTIES
            INTERFACE_INCLUDE_DIRECTORIES "${PACKAGE_PREFIX_DIR}/include"
            INTERFACE_LINK_LIBRARIES osgEarth::osgEarth)
        if(WIN32)
            set_target_properties(FreeEarth::Runtime PROPERTIES
                IMPORTED_LOCATION "${PACKAGE_PREFIX_DIR}/bin/FreeEarthRuntime${CMAKE_SHARED_LIBRARY_SUFFIX}"
                IMPORTED_IMPLIB "${PACKAGE_PREFIX_DIR}/lib/${CMAKE_IMPORT_LIBRARY_PREFIX}FreeEarthRuntime${CMAKE_IMPORT_LIBRARY_SUFFIX}")
        else()
            set_target_properties(FreeEarth::Runtime PROPERTIES
                IMPORTED_LOCATION "${PACKAGE_PREFIX_DIR}/lib/${CMAKE_SHARED_LIBRARY_PREFIX}FreeEarthRuntime${CMAKE_SHARED_LIBRARY_SUFFIX}")
        endif()
    endif()
else()
    include("${CMAKE_CURRENT_LIST_DIR}/ShEarthSDKTargets.cmake")
endif()
check_required_components(ShEarthSDK)
