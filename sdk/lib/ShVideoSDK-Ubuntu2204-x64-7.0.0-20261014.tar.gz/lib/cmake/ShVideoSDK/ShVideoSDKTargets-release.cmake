#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "VideoSDK::Runtime" for configuration "Release"
set_property(TARGET VideoSDK::Runtime APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(VideoSDK::Runtime PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libvideoSDK.so"
  IMPORTED_SONAME_RELEASE "libvideoSDK.so"
  )

list(APPEND _cmake_import_check_targets VideoSDK::Runtime )
list(APPEND _cmake_import_check_files_for_VideoSDK::Runtime "${_IMPORT_PREFIX}/lib/libvideoSDK.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
