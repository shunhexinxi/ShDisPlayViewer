# ShVideoSDK SDK developer package

Maintainer: shunhe. Platform: ubuntu2204-x64.

Only public API headers, compiled libraries, CMake metadata and notices are included.
The SDK implementation and library are distributed under separate SDK terms.
Public API declarations retain Apache-2.0; external Qt/FFmpeg/OSG components retain their own licenses.
Library names and C++ namespaces remain ABI-compatible.
SDK terms are a draft awaiting publisher finalization.
