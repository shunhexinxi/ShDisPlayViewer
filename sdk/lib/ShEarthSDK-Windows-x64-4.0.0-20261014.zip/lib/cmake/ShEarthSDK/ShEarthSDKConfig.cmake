﻿include(CMakeFindDependencyMacro)
find_dependency(Qt6 6.11 COMPONENTS Core Gui Widgets OpenGL OpenGLWidgets)
get_filename_component(_freeearth_prefix "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)
set(FREEEARTHSDK_RUNTIME_DIR "${_freeearth_prefix}/bin")
if(NOT TARGET FreeEarth::Runtime)
  add_library(FreeEarth::Runtime SHARED IMPORTED)
  set_target_properties(FreeEarth::Runtime PROPERTIES
    IMPORTED_LOCATION "${_freeearth_prefix}/bin/FreeEarthRuntime.dll"
    IMPORTED_IMPLIB "${_freeearth_prefix}/lib/FreeEarthRuntime.lib"
    INTERFACE_INCLUDE_DIRECTORIES "${_freeearth_prefix}/include")
endif()
